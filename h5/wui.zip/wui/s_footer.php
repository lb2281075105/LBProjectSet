<?php include "header.php" ?>



<header class='demos-header'>
      <h1 class="demos-title">Footer</h1>
    </header>

    <div class='demos-content-padded'>
      <div class="weui-footer">
        <p class="weui-footer__text">Copyright © 2008-2016 weui.io</p>
      </div>
      <br>
      <br>
      <div class="weui-footer">
        <p class="weui-footer__links">
          <a href="javascript:void(0);" class="weui-footer__link">底部链接</a>
        </p>
        <p class="weui-footer__text">Copyright © 2008-2016 weui.io</p>
      </div>
      <br>
      <br>
      <div class="weui-footer">
        <p class="weui-footer__links">
          <a href="javascript:void(0);" class="weui-footer__link">底部链接</a>
          <a href="javascript:void(0);" class="weui-footer__link">底部链接</a>
        </p>
        <p class="weui-footer__text">Copyright © 2008-2016 weui.io</p>
      </div>
      <div class="weui-footer weui-footer_fixed-bottom">
        <p class="weui-footer__links">
          <a href="http://jqweui.com" class="weui-footer__link">jQuery-WeUI 首页</a>
        </p>
        <p class="weui-footer__text">Copyright © 2016 jqweui.io</p>
      </div>
    </div>
<?php include "footer.php" ?>
