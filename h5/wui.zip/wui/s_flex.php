
<?php include "header.php"?>
    <style>
      .placeholder {
        margin: 5px;
        padding: 0 10px;
        background-color: #ebebeb;
        height: 2.3em;
        line-height: 2.3em;
        text-align: center;
        color: #cfcfcf;
      }
    </style>
  </head>

  <body ontouchstart>
    <header class='demos-header'>
      <h1 class="demos-title">Flex</h1>
    </header>

    <div class="weui-flex">
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
    </div>
    <div class="weui-flex">
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
    </div>
    <div class="weui-flex">
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
    </div>
    <div class="weui-flex">
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
    </div>
    <div class="weui-flex">
      <div><div class="placeholder">weui</div></div>
      <div class="weui-flex__item"><div class="placeholder">weui</div></div>
      <div><div class="placeholder">weui</div></div>
    </div>


    <?php include "footer.php"?>