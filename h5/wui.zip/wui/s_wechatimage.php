<?php include "header.php" ?>


   
           <section class="weui-menu border-none  " >

            <div class="weui-menu-inner  ">

                <img src="images/tx1.jpg" alt="">

            </div>

            <div class="weui-menu-inner border-none  bg-danger ">

                <span>收藏</span>

            </div>

            <div class="weui-menu-inner border-none color-white bg-orange ">

                <span>投递该职位</span>

            </div>


</section>
<?php include "footer.php" ?>
