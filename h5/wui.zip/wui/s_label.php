<?php include "header.php"?>
<style>

</style>
<div class="pd-15 mat-40 bg-white">
<div class="weui-label-list">
    <label class="weui-label-e">金庸</label>
    <label class="weui-label-e flat">功夫</label>
    <label class="weui-label-e">悬疑</label>
    <label class="weui-label-e flat bdc-blue f-blue">悬疑</label>
    <label class="weui-label-e">盗墓笔记</label>
    <label class="weui-label-e">欢乐谷</label>
</div>
<div class="weui-label-list">
    <label class="weui-label-s">金庸</label>
    <label class="weui-label-s f-green bdc-green flat ">扁平的</label>
    <label class="weui-label-s f-blue bdc-blue">悬疑</label>
    <label class="weui-label-s f-yellow bdc-yellow">盗墓笔记</label>
    <label class="weui-label-s f-red bdc-red">欢乐谷</label>
</div>

    <div class="weui-label-list">
        <span class="weui-badge" style="margin-left: 5px;">New</span>
        <span class="weui-badge" style="margin-left: 5px;">8</span>
        <span class="weui-badge bg-green" style="margin-left: 5px;">绿色</span>
        <span class="weui-badge bg-blue" style="margin-left: 5px;">蓝色</span>
        <span class="weui-badge bg-yellow" style="margin-left: 5px;">黄色</span>
        <span class="weui-badge bg-orange" style="margin-left: 5px;">橙色</span>
        <span class="weui-badge bg-cyan" style="margin-left: 5px;">青色</span>
        <span class="weui-badge bg-red" style="margin-left: 5px;">红色</span>
        <span class="weui-badge bg-gray" style="margin-left: 5px;">灰色</span>
        <span class="weui-badge bg-black" style="margin-left: 5px;">黑色</span>
    </div>


</div>
<?php include "footer.php"?>
