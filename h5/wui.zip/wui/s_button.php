<?php include "header.php"?>
<div class="page__hd">
    <h1 class="page__title">Button</h1>
    <p class="page__desc">按钮</p>
</div>



<div class='demos-content-padded'>
    <a href="javascript:;" class="weui-btn weui-btn_primary">页面主操作</a>
    <a href="javascript:;" class="weui-btn weui-btn_primary weui-btn_loading"><i class="weui-loading"></i>页面主操作 Loading</a>
    <a href="javascript:;" class="weui-btn weui-btn_warn weui-btn_loading">正在加载...</a>

    <a href="javascript:;" class="weui-btn weui-btn_disabled weui-btn_primary">禁用按钮</a>
    <a href="javascript:;" class="weui-btn weui-btn_warn">警告按钮</a>
    <a href="javascript:;" class="weui-btn weui-btn_blue ">蓝色按钮</a>
    <a href="javascript:;" class="weui-btn weui-btn_cyan flat">青色扁平按钮</a>
    <a href="javascript:;" class="weui-btn weui-btn_disabled weui-btn_warn">禁用按钮</a>
    <a href="javascript:;" class="weui-btn weui-btn_default">默认按钮</a>


    <a href="javascript:;" class="weui-btn weui-btn_plain-default">扁平线框按钮</a>
    <a href="javascript:;" class="weui-btn weui-btn_plain-primary">扁平主按钮</a>

    <div class="button_sp_area">
        <a href="javascript:;" class="weui-btn weui-btn_mini weui-btn_primary round">按钮</a>
        <a href="javascript:;" class="weui-btn weui-btn_mini weui-btn_default">按钮</a>
        <a href="javascript:;" class="weui-btn weui-btn_mini weui-btn_warn">按钮</a>
        <a href="javascript:;" class="weui-btn weui-btn_mini weui-btn_blue">按钮</a>
    </div>


</div>


<?php include "footer.php"?>
