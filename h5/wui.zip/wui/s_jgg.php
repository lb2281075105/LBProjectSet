<?php include "header.php" ?>


<div class="weui-grids">
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
    <a href="javascript:;" class="weui-grid">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label">Grid</p>
    </a>
</div>

<?php include "footer.php" ?>
