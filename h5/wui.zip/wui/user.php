<?php include "header.php"?>



    <div class="weui-cell pd-40 bg-white mab-40">
        <div class="weui-cell__hd" style="position: relative;margin-right: 10px;">
            <img src="images/tx2.jpg" style="width: 80px;display: block ;border-radius: 50%">

        </div>
        <div class="weui-cell__bd">
            <p>联系人</p>
            <p style="font-size: 13px;color: #888888;">15845261423</p>
        </div>
    </div>

<!--基本信息-->

<div class="weui-cells__title">基本信息</div>
<div class="weui-cells">

        <div class="weui-cell">
            <div class="weui-cell__bd">
                <span style="vertical-align: middle">兴趣爱好</span>
                <p class="weui-media-box__desc">个人爱好</p>
            </div>

            <div class="weui-cell__ft">详细信息</div>
        </div>

        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__bd">
                <span style="vertical-align: middle">我的简历</span>
                <p class="weui-media-box__desc">个人简历</p>
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__bd">
                <span style="vertical-align: middle">我的收藏</span>
                <p class="weui-media-box__desc">个人收藏</p>
            </div>
            <div class="weui-cell__ft"></div>
        </div>

    </div>





<?php include "footer.php"?>
