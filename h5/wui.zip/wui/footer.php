<!--<style>
    .page__ft.j_bottom {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
    }

    .page__ft img {
        height: 19px;
    }
    .page__ft {
        padding-top: 40px;
        padding-bottom: 10px;
        text-align: center;
    }

</style>
<div class="page__ft j_bottom">
    <a href="javascript:home()"><img src="images/icon_footer.png"></a>
</div>
-->
<script src="js/fastclick.js"></script>

<script>
    $(function() {
        FastClick.attach(document.body);
    });
</script>


</body>
</html>