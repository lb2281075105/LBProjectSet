<?php include "header.php"?>

<section class="weui-menu " >

    <div class="weui-menu-inner  ">

        <span>收藏</span>

    </div>

    <div class="weui-menu-inner ">

        <span>收藏</span>

    </div>

    <div class="weui-menu-inner  ">

        <span>投递该职位</span>

    </div>


</section>



