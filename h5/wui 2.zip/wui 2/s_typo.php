<?php include "header.php" ?>

<p>默认字体大小16px, 行高为1.6</p>
<h1>标题：h1, 18px</h1>
<h2>栏目：h2, 17px</h2>
<h3>内文：导航，正文段落h3, 16px</h3>
<h4>内文：人名歌名标题等h4, 16px</h4>
<h5>副内文：h5, 同text-sub, 14px</h5>
<h6>辅助文字：h6, 同text-tips, 12px</h6>

<!--
<p class="color-white">主要内容色</p>
<p class="color-black" >主要内容反色</p>
<p class="color-orange">辅助次要内容色</p>
<p class="color-error">时间，输入框，不可点击状态文本色</p>
<p class="color-primary">警示，会员红名，搜索热词，同ui-txt-red</p>
<p class="color-success">关键词高亮，同em</p>
<p><a>链接颜色</a></p>
<p class="ui-txt-feeds">feeds链接</p>
-->

<div style="height: 60px;max-width: 640px"  class="bg-white">
<div class="weui-nowrap ">
    一行文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略
</div>
</div>


<div style="height: 80px;max-width: 640px"  class="bg-white">
<div class="weui-nowrap-multi ">
    多行文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略，内容文字超出长度省略
</div>
</div>


<p>两端绝对对齐</p>

<div style="width: 200px;background: goldenrod;padding: 15px;">



    <p class="text-justify">普通的多行文本内容：在首个《进击的巨人》预热视频中只是描述了一个巨人恰好拿起一人准备放进嘴巴里面，而另个场景则是超大型巨人附着浓重的烟雾将巨手拍下来。将于今年8月1日上映。</p>

</div>
<?php include "footer.php"?>
