<?php include "header.php" ?>


<div class="weui-image-total">
<div class="weui-image-position">
        <img src="images/net1.png">

</div>
<div class="weui-wunet">无法连接到网络</div>
<div class="weui-wunet-1 pdt-5">请检查网络设置后重试，或者直接反馈给我们</div>
<div class="weui-wunet-1">我们-设置-意见反馈</div>


</div>



<?php include "footer.php" ?>
