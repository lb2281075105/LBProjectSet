<?php include "header.php" ?>


<div class="weui-grids">

    <a href="list.php" class="weui-grid weui-grid-4 bg-orangel">
        <div class="weui-grid__icon">
            <img src="./images/sxy.png" alt="">
        </div>
        <p class="weui-grid__label fs-white">商学院</p>
        <p class="weui-grid__label bg-black7 fs-white">商学院</p>
    </a>

    <a href="user.php" class="weui-grid  weui-grid-4 bg-orangel">
        <div class="weui-grid__icon">
            <img src="./images/zs.png" alt="">
        </div>
        <p class="weui-grid__label fs-white">招商合作</p>
        <p class="weui-grid__label bg-black7 fs-white">商学院</p>

    </a>
    <a href="javascript:;" class="weui-grid  weui-grid-4 bg-orangel">
        <div class="weui-grid__icon">
            <img src="./images/hr.png" alt="">
        </div>
        <p class="weui-grid__label fs-white">人力资源</p>
        <p class="weui-grid__label bg-black7 fs-white">商学院</p>

    </a>
    <a href="javascript:;" class="weui-grid  weui-grid-4 bg-orangel">
        <div class="weui-grid__icon">
            <img src="./images/kf.png" alt="">
        </div>
        <p class="weui-grid__label fs-white">客服中心</p>
        <p class="weui-grid__label bg-black7 fs-white">商学院</p>

    </a>

    <a href="javascript:;" class="weui-grid  weui-grid-4 bg-orangel">
        <div class="weui-grid__icon">
            <img src="./images/yf.png" alt="">
        </div>
        <p class="weui-grid__label fs-white">软件研发</p>
        <p class="weui-grid__label bg-black7 fs-white">商学院</p>
    </a>

    <a href="javascript:;" class="weui-grid   weui-grid-4 bg-orangel">
        <div class="weui-grid__icon">
            <img src="./images/bld.png" alt="">
        </div>
        <p class="weui-grid__label fs-white">便利店</p>
        <p class="weui-grid__label bg-black7 fs-white">商学院</p>

    </a>

    <a href="javascript:;" class="weui-grid weui-grid-4 bg-orangel">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label fs-white">商学院</p>
        <p class="weui-grid__label bg-black7 fs-white">商学院</p>

    </a>
    <a href="javascript:;" class="weui-grid weui-grid-4 bg-orangel">
        <div class="weui-grid__icon">
            <img src="./images/icon_tabbar.png" alt="">
        </div>
        <p class="weui-grid__label fs-white">Grid</p>
        <p class="weui-grid__label bg-black7 fs-white">商学院</p>
    </a>
</div>
<div class="pdt-10 pdl-10 fs-18">明嗔阁----您身边的改运专家</div>
<div class="pdt-10 pdl-50 fs-18">一份吉祥礼</div>
<div class="pdt-10 pd-center fs-18">一生福禄寿</div>






<?php include "footer.php" ?>
