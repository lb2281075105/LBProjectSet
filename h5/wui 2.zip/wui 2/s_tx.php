<?php include "header.php" ?>


<a class="weui-block  text-center " style="background: url('images/bg.png') no-repeat;background-size: 100% 100%;">
    <div class="weui-block-content" style="padding: 80px 0px 1px;">
        <img class="img-avatar img-avatar-thumb" src="images/tx3.png" alt="">
    </div>
    <div class="weui-block-content  pb-30 pt-10">
        <div class="font-w600 text-white mb-5" style="background-color: red;">宋英杰</div>
        <div class="text-white">很好看嘛</div>
    </div>
</a>


<?php include "footer.php"?>
