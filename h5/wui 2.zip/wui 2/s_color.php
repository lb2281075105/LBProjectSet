<?php include "header.php" ?>
    <div class="page__hd">
        <h1 class="page__title">Color</h1>
        <p class="page__desc">配色</p>
    </div>
    <div class="demos-content-padded">
        <h1>字体大小与颜色</h1>
        <h2>字体大小与颜色</h2>
        <h3>字体大小与颜色</h3>
        <h4>字体大小与颜色</h4>
        <h5>字体大小与颜色</h5>
        <h6>字体大小与颜色</h6>

        <p><span class='f11'>字体f11</span><span class='f12'>字体f12</span><span class='f13'>字体f13</span><span class='f114'>字体f14</span><span class='f15'>字体15</span><span class='f116'>字体f16</span><span class='f31'>字体f31</span><span class='f32'>字体f32</span><span class='f35'>字体f35</span><span class='f40'>字体f40</span><span class='f45'>字体f45</span><span class='f50'>字体f50</span><span class='f55'>字体f55</span></p>


        <div class="xs-title xs-title-mr"><div class="xs-title-b bg-green"></div><h2 class="xs-title-e ">字体颜色</h2></div>


        <p>
            <span class='f-red'>醉过才知酒浓，爱过才知情重。</span>



            <span class='f-cyan'>醉过才知酒浓，爱过才知情重。你不能做我的诗，正如我不能做你的梦。</span>



            <span class='f-green'>醉过才知酒浓，爱过才知情重。你不能做我的诗，正如我不能做你的梦。</span>


            <span class='f-blue'>醉过才知酒浓，爱过才知情重。你不能做我的诗，正如我不能做你的梦。</span>



            <span class='f-black'>醉过才知酒浓，爱过才知情重。你不能做我的诗，正如我不能做你的梦。</span>



            <span class='f-gray '>醉过才知酒浓，爱过才知情重。你不能做我的诗，正如我不能做你的梦。</span>



            <span class='f-yellow'>醉过才知酒浓，爱过才知情重。你不能做我的诗，正如我不能做你的梦。</span>




            <span class='f-orange'>醉过才知酒浓，爱过才知情重。你不能做我的诗，正如我不能做你的梦。</span>
        </p>


        <div class="xs-title xs-title-mr"><div class="xs-title-b bg-green"></div><h2 class="xs-title-e ">背景颜色</h2></div>
        <p>


              <span class='f-white bg-blue'>背景蓝色bg-blue</span>
            <span class='bg-orange f-white'>bg-orange</span>
            <span class='bg-cyan f-white'>bg-cyan</span>
            <span class='weui_btn_primary f-white'>背景绿色weui_btn_primary</span>
            <span class='weui_btn_warn f-white'>weui_btn_warn</span>

            <span class='weui_btn_default f-red'>weui_btn_default</span>
        </p>


    </div>
<?php include "footer.php" ?>