<?php include "header.php" ?>


<div class="weui-image-total">
<div class="weui-image-position">
        <img src="images/net2.png">

</div>
<!-- <div class="weui-wunet">无法连接到网络</div> -->
<div class="weui-wunet-1 pdt-5">网络链接异常，请检查网络设置</div>
<div class="weui-wunet-1"><button>重新加载</button></div>
</div>

<?php include "footer.php" ?>
