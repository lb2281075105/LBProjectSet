<?php include "header.php" ?>

    <style>
        .ff{
            background: red;
            display: flex;
            justify-content:space-between;
            height: 80px;
            align-items:flex-start ;
        }
    </style>

    <div class="demos-content-padded">


        <div class="ff">
<div style="background-color: green">四十岁</div>
            <div style="background-color: yellow">是多少</div>
            <div style="background-color: yellow">是多少2</div>
        </div>
    </div>
<?php include "footer.php" ?>