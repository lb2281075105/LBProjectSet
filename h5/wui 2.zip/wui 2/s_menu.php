<?php include "header.php" ?>
<style>
    .weui-tiled {
        display: -webkit-box;
        width: 100%;
        -webkit-box-sizing: border-box;
    }
    .weui-tiled li {
        -webkit-box-flex: 1;
        width: 100%;
        text-align: center;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-box-pack: center;
        -webkit-box-align: center;
    }
</style>
<div style="height: 60px" class="bg-white">
    <ul class="weui-tiled">
        <li><div>菜单</div><i>1</i></li>
        <li><div>菜单</div><i>2</i></li>
        <li><div>菜单</div><i>3</i></li>
        <li><div>菜单</div><i>3</i></li>
        <li><div>菜单</div><i>3</i></li>
        <li><div>菜单</div><i>3</i></li>
    </ul>
</div>
<?php include "footer.php"?>
