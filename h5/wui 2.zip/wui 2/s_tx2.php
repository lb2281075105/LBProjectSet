<?php include "header.php" ?>

<div class="bg-white">
    <a class="weui-block" href="javascript:void(0)">
        <div class="weui-block-content  clearfix">
            <div class="float-right">
                <img class="img-avatar" src="images/tx002.jpg" alt="">
            </div>
            <div class="float-left mt-10">
                <div class="font-w600 mb-5">软件测试工程师</div>
                <div class="text-muted">很好呀</div>
            </div>
        </div>
    </a>
</div>

<div class="bg-white" style="margin-top: 30px">
    <a class="weui-block " href="javascript:void(0)">
        <div class="weui-block-content  clearfix">
            <div class="text-right float-right mt-10">
                <div class="font-w600 mb-5">宋先生</div>
                <div class="text-muted">你好</div>
            </div>
            <div class="float-left">
                <img class="img-avatar" src="images/tx001.jpg" alt="">
            </div>
        </div>
    </a>
</div>
<div class="bg-white" style="margin-top: 30px">
        <div style="display: flex;flex-direction: row;align-items: center;margin: 0px 10px;padding: 10px 0px;">
            <div style="display: flex;flex-direction: column;flex: 1;">
                <span>宋先生</span>
                <span>宋先生</span>
               <!--  <div class="">你好</div> -->
            </div>
            <div style="background-color: green;display: flex;align-items: center;">
                <img class="img-avatar" src="images/tx001.jpg" alt="" style="background-color: red;">
            </div>
        </div>
</div>

<?php include "footer.php"?>