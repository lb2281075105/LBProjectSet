<?php include "header.php" ?>


    <header class='demos-header'>
      <h1 class="demos-title">Select</h1>
    </header>

    
    <div class="weui-cells weui-cells_form">
      <div class="weui-cell">
        <div class="weui-cell__hd"><label for="name" class="weui-label">职业</label></div>
        <div class="weui-cell__bd">
          <input class="weui-input" id="job" type="text" value="">
        </div>
      </div>

      <div class="weui-cell">
        <div class="weui-cell__hd"><label for="name" class="weui-label">手机</label></div>
        <div class="weui-cell__bd">
          <input class="weui-input" id="mobile" type="text" value="">
        </div>
      </div>
      <div class="weui-cell">
        <div class="weui-cell__hd"><label for="name" class="weui-label">爱好</label></div>
        <div class="weui-cell__bd">
          <input class="weui-input" id="in" type="text" value="">
        </div>
      </div>
    </div>


    <script>
      $("#job").select({
        title: "选择职业",
        items: ["法官", "医生", "猎人", "学生", "记者", "其他"],
        onChange: function(d) {
          console.log(this, d);
        },
        onClose: function() {
          console.log("close");
        },
        onOpen: function() {
          console.log("open");
        },
      });
      $("#mobile").select({
        title: "选择手机",
        items: [
          {
            title: "iPhone 3GS",
            value: "001",
          },
          {
            title: "iPhone 5",
            value: "002",
          },
          {
            title: "iPhone 5S",
            value: "003",
          },
          {
            title: "iPhone 6",
            value: "004",
          },
          {
            title: "iPhone 6S",
            value: "005",
          },
          {
            title: "iPhone 6P",
            value: "006",
          },
          {
            title: "iPhone 6SP",
            value: "007",
          },
          {
            title: "iPhone SE",
            value: "008",
          },
          {
            title: "iPhone 7",
            value: "009"
          }
        ]
      });
      $("#in").select({
        title: "您的爱好",
        multi: true,
        min: 2,
        max: 3,
        items: [
          {
            title: "画画",
            value: 1,
            description: "额外的数据1"
          },
          {
            title: "打球",
            value: 2,
            description: "额外的数据2"
          },
          {
            title: "唱歌",
            value: 3,
            description: "额外的数据3"
          },
          {
            title: "游泳",
            value: 4,
            description: "额外的数据4"
          },
          {
            title: "健身",
            value: 5,
            description: "额外的数据5"
          },
          {
            title: "睡觉",
            value: 6,
            description: "额外的数据6"
          },
        ],
        beforeClose: function(values, titles) {
          if(values.indexOf("6") !== -1) {
            $.toast("不能选睡觉", "cancel");
            return false;
          }
          return true;
        },
        onChange: function(d) {
          console.log(this, d);
        },
        onClose: function (d) {
          console.log('close')
        }
      });
    </script>
<?php include "footer.php" ?>
