<?php include "../../s/headerin.php" ?>



<header class='demos-header'>

    <h1 class="demos-title"><i class="iconfont f-20">&#xe67e;</i> 图文混排 <span class="f-12 f-gray">推荐此图文</span></h1>
</header>



<div class="demos-content-padded">
    <div class="xs-title xs-title-mr"><div class="xs-title-b bg-green"></div><h2 class="xs-title-e ">图文混排：文字上图下</h2></div>
    <div class="weui-cell-3">
        <div class="bg-white weui-cell-a pdb-15"><div class="pdt-15">特惠KTV</div><div class="fs-14 f-red">海昌9元</div><img src="images/4390.png"></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a pdb-15"><div class="pdt-15">特惠KTV</div><div class="fs-14 f-red">海昌9元</div><img src="images/4391.png"></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a pdb-15"><div class="pdt-15">特惠KTV</div><div class="fs-14 f-red">海昌9元</div><img src="images/4392.png"></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a pdb-15"><div class="pdt-15">特惠KTV</div><div class="fs-14 f-red">海昌9元</div><img src="images/4393.png"></div>
    </div>
    <div class="weui-cell-height bg-gray"></div>
    <div class="weui-cell-3">
        <div class="bg-white weui-cell-a pdb-15"><div class="pdt-15">特惠KTV</div><div class="fs-14 f-red">海昌9元</div><img src="images/4390.png"></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a pdb-15"><div class="pdt-15">特惠KTV</div><div class="fs-14 f-red">海昌9元</div><img src="images/4391.png"></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a pdb-15"><div class="pdt-15">特惠KTV</div><div class="fs-14 f-red">海昌9元</div><img src="images/4392.png"></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a pdb-15"><div class="pdt-15">特惠KTV</div><div class="fs-14 f-red">海昌9元</div><img src="images/4393.png"></div>
    </div>

</div>

<?php include "../../s/footerin.php"?>
