<?php include "../../s/headerin.php" ?>



<header class='demos-header'>

    <h1 class="demos-title"><i class="iconfont f-20">&#xe67e;</i> List列表 <span class="f-12 f-gray">推荐此List</span></h1>
</header>


<!-- 分割 -->
<div class="weui-cells__title weui-cell-top-nav">品质购团<span class="weui-cell-more f-gray">更多</span></div>
<div class="weui-cells">

    <div class="weui-cell-topIcon-style">
         <div class="weui-cell-topIcon">
             <img src="imgs/topIcon1.png" class="weui-cells-top-images">
          </div>
    </div>
    
 <div class="weui-cell-bottom-pd mglr-10">
    <div class="weui-cell-bottom-image">
      <div class="weui-cell-bottom-bootom1">
             <img src="imgs/bottom1.png">
      </div>
      <div class="bg-white" style="width: 10px;"></div>
      <div class="weui-cell-bottom-bootom1" >
             <img src="imgs/bottom2.png">
      </div>
      <div style="width: 10px;" class="bg-white"></div>
      <div class="weui-cell-bottom-bootom1">
             <img src="imgs/bottom3.png">
      </div>
    </div>
 </div>

</div>


<?php include "../../s/footerin.php"?>
