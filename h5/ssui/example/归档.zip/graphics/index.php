<?php include "../../s/headerin.php" ?>



<header class='demos-header'>

    <h1 class="demos-title"><i class="iconfont f-20">&#xe67e;</i> 图文混排 <span class="f-12 f-gray">推荐此图文</span></h1>
</header>



<div class="demos-content-padded">
    <div class="xs-title xs-title-mr"><div class="xs-title-b bg-green"></div><h2 class="xs-title-e ">图文混排</h2></div>
    <div class="bg-white">
        <div class="pdt-5">马云又一神作！！！马云又一神作！！！马云又一神作！！！马云又一神作</div>
        <div class="weui-cell-image pdt-15 pdb-10">
           <div class="weui-cell-image-3"><img src="images/4430.png"></div>
           <div class="weui-cell-width bg-gray"></div>
           <div class="weui-cell-image-3"><img src="images/4431.png"></div>
           <div class="weui-cell-width bg-gray"></div>
           <div class="weui-cell-image-3"><img src="images/4432.png"></div>
        </div>
        <div class="fs-12 f-gray pdb-10">不得不说<span class="pdl-10">1万人看过</span></div>
    </div>
    <div class="weui-cell-height bg-gray"></div>
     <div class="bg-white">
        <div class="pdt-5">马云又一神作！！！马云又一神作！！！马云又一神作！！！马云又一神作</div>
        <div class="weui-cell-image pdt-15 pdb-10">
           <div class="weui-cell-image-3"><img src="images/4430.png"></div>
           <div class="weui-cell-width bg-gray"></div>
           <div class="weui-cell-image-3"><img src="images/4431.png"></div>
           <div class="weui-cell-width bg-gray"></div>
           <div class="weui-cell-image-3"><img src="images/4432.png"></div>
        </div>
        <div class="fs-12 f-gray pdb-10">不得不说<span class="pdl-10">1万人看过</span></div>
    </div>

</div>


<?php include "../../s/footerin.php"?>
