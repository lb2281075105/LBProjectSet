<?php include "../../s/headerin.php" ?>



<header class='demos-header'>

    <h1 class="demos-title"><i class="iconfont f-20">&#xe67e;</i> 图文混排 <span class="f-12 f-gray">推荐此图文</span></h1>
</header>



<div class="demos-content-padded">
    <div class="xs-title xs-title-mr"><div class="xs-title-b bg-green"></div><h2 class="xs-title-e ">5个图:图上文字下</h2></div>
    <div class="weui-cell-3">
        <div class="bg-white weui-cell-a"><img src="images/1062.png"> <div>特惠KTV</div><div class="fs-14 f-red pdb-15">海昌9元</div></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a"><img src="images/1063.png"><div>特惠KTV</div><div class="fs-14 f-red pdb-15">海昌9元</div></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a"><img src="images/1062.png"><div>特惠KTV</div><div class="fs-14 f-red pdb-15">海昌9元</div></div>
    </div>
    <div class="weui-cell-height bg-gray"></div>
    <div class="weui-cell-3">
        <div class="bg-white weui-cell-a"><img src="images/1062.png"> <div>特惠KTV</div><div class="fs-14 f-red pdb-15">海昌9元</div></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a"><img src="images/1063.png"><div>特惠KTV</div><div class="fs-14 f-red pdb-15">海昌9元</div></div>
        <div class="weui-cell-width bg-gray"></div>
        <div class="bg-white weui-cell-a"><img src="images/1062.png"><div>特惠KTV</div><div class="fs-14 f-red pdb-15">海昌9元</div></div>
    </div>

</div>

<?php include "../../s/footerin.php"?>
