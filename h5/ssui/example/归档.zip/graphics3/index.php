<?php include "../../s/headerin.php" ?>



<header class='demos-header'>

    <h1 class="demos-title"><i class="iconfont f-20">&#xe67e;</i> List列表 <span class="f-12 f-gray">推荐此List</span></h1>
</header>
<div class="weui-cells__title">特色服务模块</div>
<div class="weui-cells">
<div class="weui-cell-topIcon-style">
         <div class="weui-cell-topIcon">
             <img src="imgs/topIcon.png" class="weui-cells-top-images">
          </div>
</div>
          <div class="weui-cell-bottom">
  
  <div class="f-gray">
        <img src="imgs/签证.png" style="width: 25px;height: 25px;">
        <div class="f-13 pdb-5">代理签证</div>
  </div>

  <div class="f-gray">
        <img src="imgs/留学.png" style="width: 25px;height: 25px;">
        <div class="f-13 pdb-5">留学快汇</div> 
  </div>

  <div class="f-gray">
        <img src="imgs/结汇.png" style="width: 25px;height: 25px;">
        <div class="f-13 pdb-5">外汇结汇</div>    
  </div>

  <div>
      
  <div class="f-gray">
        <img src="imgs/购汇.png" style="width: 25px;height: 25px;">
        <div class="f-13 pdb-5">外汇购汇</div>      
  </div>

</div>


</div>


</div>



<?php include "../../s/footerin.php"?>
