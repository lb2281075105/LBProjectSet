<?php include "../../s/headerin.php" ?>



<header class='demos-header'>

    <h1 class="demos-title"><i class="iconfont f-20">&#xe67e;</i> List列表 <span class="f-12 f-gray">推荐此List</span></h1>
</header>

<div class="demos-content-padded">
    <div class="xs-title xs-title-mr"><div class="xs-title-b bg-green"></div><h2 class="xs-title-e ">免费申请列表</h2></div>
</div>
    <div class="page__bd">
      <div class="weui-panel weui-panel_access">
        <div class="weui-panel__bd">
          <a href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg">
            
           <div class="weui-media-box__bd">
              <div class="weui-panel-free f-orange" >
                 <div class="weui-cell-free-left fs-25">￥0</div>
                 <div class="weui-cell-free-right fs-12 f-grayy">
                    <div class="pdl-5 pdr-5"><span>原价</span><span>￥1980</span></div>
                    <div class="pdl-5 pdr-5"><span>折扣</span><span>0</span></div>
                    <div class="pdl-5 pdr-5"><span>节省</span><span>￥1980</span></div>
                  </div>
                               
              </div>
              </div>
          </a>
          <a href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg">
              <div class="weui-media-box__bd">
                       <div class="weui-media-box__desc"><span class="f-orange fs-14 f-grayy">已有<span class="f-red pdl-5 pdr-5">5089</span>人疯抢</span><span class="f-orange fs-14 weui-media-free__desc-right f-orange">00<span class="f-red pdlr-3">天</span>01<span class="f-red pdlr-3">小时</span>54<span class="f-red pdlr-3">分</span>35<span class="f-red pdlr-3">秒</span></span></div>
              <div class="weui-cell-button pd-5 mat-10 fs-14 bg-orangeshen fs-white">免费申请</div>

            </div>
          </a>
        </div>
</div>
    <div class="page__bd">
      <div class="weui-panel weui-panel_access">
        <div class="weui-panel__bd">
          <a href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg">
            
           <div class="weui-media-box__bd">
              <div class="weui-panel-free f-orange" >
                 <div class="weui-cell-free-left fs-25">￥0</div>
                 <div class="weui-cell-free-right fs-12 f-grayy">
                    <div class="pdl-5 pdr-5"><span>原价</span><span>￥1980</span></div>
                    <div class="pdl-5 pdr-5"><span>折扣</span><span>0</span></div>
                    <div class="pdl-5 pdr-5"><span>节省</span><span>￥1980</span></div>
                  </div>
                               
              </div>
              </div>
          </a>
          <a href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg">
              <div class="weui-media-box__bd">
                       <div class="weui-media-box__desc"><span class="f-orange fs-14 f-grayy">已有<span class="f-red pdl-5 pdr-5">5089</span>人疯抢</span><span class="f-orange fs-14 weui-media-free__desc-right f-orange">00<span class="f-red pdlr-3">天</span>01<span class="f-red pdlr-3">小时</span>54<span class="f-red pdlr-3">分</span>35<span class="f-red pdlr-3">秒</span></span></div>
              <div class="weui-cell-button pd-5 mat-10 fs-14 fs-white bg-orangeshen">免费申请</div>

            </div>
          </a>
        </div>

      </div>


<?php include "../../s/footerin.php"?>
