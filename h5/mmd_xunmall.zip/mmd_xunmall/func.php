<?php

echo '调用 func.php';