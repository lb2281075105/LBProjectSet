<?php
/**
 *
 * @author Gorden
 * @url http://bbs.we7.cc/
 */
echo webtest;

