/**
 * 路径: addons/we7_store/template/js/test.js
 */

function hello(){
	return 'hello world';
}