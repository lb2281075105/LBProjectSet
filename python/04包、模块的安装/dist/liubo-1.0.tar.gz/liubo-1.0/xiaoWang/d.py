#coding=utf-8

def bFunc():
	print("bFunc")