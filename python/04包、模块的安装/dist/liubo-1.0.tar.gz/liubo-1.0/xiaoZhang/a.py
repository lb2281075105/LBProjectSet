#coding=utf-8

def aFunc():
	print("-----aFunc-----")