from distutils.core import setup

setup(name="liubo",version="1.0",description="liubo's module",author="liubo",py_modules=['xiaoWang.c','xiaoWang.d','xiaoZhang.a','xiaoZhang.b'])